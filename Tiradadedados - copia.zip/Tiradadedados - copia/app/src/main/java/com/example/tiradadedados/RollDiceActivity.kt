package com.example.tiradadedados

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.snackbar.Snackbar

class RollDiceActivity : AppCompatActivity() {

    val diceface= listOf(R.drawable.area_1,
        R.drawable.area_2,
        R.drawable.area_3,
        R.drawable.area_4,
        R.drawable.area_5,
        R.drawable.area_6,
        )
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_roll_dice)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setTitle("Roll dice")
        val diceImage = findViewById<ImageView>(R.id.dice_face_image)
        diceImage.setImageResource(diceface.get(1))
        findViewById<Button>(R.id.rool_dice_button2).setOnClickListener{
            diceImage.setImageResource(diceface.random())
            Snackbar.make(diceImage, "Dice rolled", Snackbar.LENGTH_SHORT).show()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        if (item.itemId == android.R.id.home){
            finish()
        }
        return super.onOptionsItemSelected(item)
    }
}